package ʵ���3��ҵ;


public class JOpotionpane {
	public static String showInPutDialog(String string) {
		// TODO Auto-generated method stub
		return null;
	}


}
