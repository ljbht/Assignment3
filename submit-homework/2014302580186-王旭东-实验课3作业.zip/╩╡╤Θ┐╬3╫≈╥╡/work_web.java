package ʵ���3��ҵ;

public class work_web {
	String MyUrl="    ";
	String File="test.html";
	HttpRequest req=HttpRequest.get(MyUrl);

}
